// This is for Show more button in Breadcrumb
$('body').click(function(e) {
    var langCode = Liferay.ThemeDisplay.getLanguageId();
    if ($(e.target).closest('.breadcrumb_wrap').length === 0) {

        if (langCode == "hi_IN") {
            $(".showbreadcrumbdropdown span").text('\u0905\u0927\u093F\u0915 \u0926\u0947\u0916\u0947\u0902');
            $('.breadcrumb_dropdown').hide();
        } else {
            $(".showbreadcrumbdropdown span").text('Show More');
            $('.breadcrumb_dropdown').hide();
        }
    }
});
// end 

// Scrolling to top functionality
$(document).ready(function() {
    $("#btnTop").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });
    $(window).scroll(function() {
        var height = $(window).scrollTop();
        if (height > 300) {
            $('#btnTop').fadeIn();
        } else {
            $('#btnTop').fadeOut();
        }
    });

});
// end

// open pdf whic is in  navbar in new blank window
$('.navbar-nav a[href$=".pdf"] , .featureList a[href$=".pdf"]').attr('target', '_blank');
//end 

// chat bot script
$('.chat_bot_button').click(function() {
    $("#chat_box").toggle();
    $(".chat_img1").hide();
    $(".chat_img2").show();
});
$('.chat_close_icon , .chat_bot_icon , .chat_img2').click(function() {
    $("#chat_box").hide();
    $(".chat_img2").hide();
    $(".chat_img1").show();
});
$('.chat_full_screen').click(function() {
    $('#chat_box').toggleClass('chat_bot chat_bot_full')
});
// end 


$(document).ready(function() {
    // this for Foottable Table
    $('.footable').footable();
    //end 

    // for Compare product
    $('.compare_grid i').on('click', function() {
        $(this).closest(".compare_grid").remove();
    });
    $('.compare_list i').on('click', function() {
        $(this).closest(".compare_box_grid").remove();
    });
    // end 

    // Search Required validation



    // inner page Rate of Interset panel is appened in mobile view
    if ($(window).width() <= 1000) {
        $(".wrap_right_mob1:eq(0)").appendTo($(".intrest_rate_mobile"));
    };
    // end

    // to remove fixed navigation in mobile view
    var viewportScroll = $(window).width();
    if (viewportScroll > 800) {
        $(window).scroll(function() {
            if ($(this).scrollTop() > 20) {

                $('.intro').addClass('fixed');
            } else {
                $('.intro').removeClass('fixed');
            }
            if ($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
                $("footer .bg-white").removeClass("fixed-bottom");
            }
        });
    }
    // end 

    // for footer to remove fix class for mobile view
    var iScrollPos = 0;
    $(window).scroll(function() {
        var iCurScrollPos = $(this).scrollTop();
        if (iCurScrollPos > iScrollPos) {
            // scroll down
        } else {
            //scroll up
            $("footer .bg-white").addClass("fixed-bottom");
        }
        iScrollPos = iCurScrollPos;
    });

    // end

    // to increase and decrease the body font 
    var $affectedElements = $("*,body, ul li, ul li a, p, div, li, a, span, td, h1, h2, h3, h4, h5, h6, b, small");
    var size, org_size;

    function getSize() {
        size = $affectedElements.css("font-size");
        org_size = $affectedElements.css("font-size")
        size = parseInt(size, 10);

        $("#font-size").text(size);
    }
    //get inital font size
    getSize();
    $("#btn-increase").on("click", function() {
        // parse font size, if less than 20 increase font size
        if ((size + 1) <= 19) {
            $affectedElements.css("font-size", "+=1");
            $("#font-size").text(size += 1);
        }
    });
    $("#btn-decrease").on("click", function() {
        if ((size - 1) >= 14) {
            $affectedElements.css("font-size", "-=1");
            $("#font-size").text(size -= 1);
        }
    });
    $affectedElements.each(function() {
        var $this = $(this);
        $this.data("orig-size", $this.css("font-size"));
    });
    $("#btn-orig").click(function() {
        $affectedElements.each(function() {
            var $this = $(this);
            $this.css("font-size", $this.data("orig-size"));
        });
    });
    // end 

    // to open the href site in new window
    $("#navbarCollapse a[href^='https']").attr('target', '_blank');
    $(".yellow_btn a[href^='https'] , .rate-content a[href^='https").attr('target', '_blank');
    $(".yellow_btn a[href^='http']").attr('target', '_blank');
    $(".breadcrumb li a").removeAttr('target', '_blank');
    $('.apply_more_btn a[href^="https://"]').not('.apply_more_btn a[href*="/web"]').attr('target', '_blank');
    $('.rate-content a[href^="https://"]').not('.rate-content a[href*="/web"]').attr('target', '_blank');
    $('.custombreadcrumb a[href^="https://"]').not('.custombreadcrumb a[href*="/web"]').attr('target', '_blank');
    $('.button_apply_desk[href^="https://"]').not('.button_apply_desk[href*="/web"]').attr('target', '_blank');
    $('.quickLink li a[href^="https://"]').not('.quickLink li a[href*="/web"]').attr('target', '_blank');
    $('.product_slide .slick-track a[href^="https://"]').not('.product_slide .slick-track a[href*="/web"]').attr('target', '_blank');
    // end 	

    // to open href url in new tab which is there in breadcrumb 
    $('body').find('.custombreadcrumb').find('a[href$=".pdf"]').prop('target', '_blank');
    $('body').find('.breadcrumb_dropdown').find('a[href$=".pdf"]').prop('target', '_blank');
    // end 





    //rate of Interset
    function showSelectedColor(rate) {
        var selector = "#menu-" + rate;
        $('.rate_fade').not(selector).hide();
        $(selector).show();
    } //call showSelectedColor on change of sleect element 
    $("#rate-picker").change(function() {
        var rate = $(this).val();
        showSelectedColor(rate);
    });
    var rate_for_woman = $('.rate_active').find(".for_woman").eq(0).find('h2').text();
    var rate_for_other = $('.rate_active').find(".for_other").eq(0).find('h2').text();
    $(".rt").html("");
    $(".rt").html(rate_for_woman);
    $(".rt-other").html("");
    $(".rt-other").html(rate_for_other);
    //end
    // dropdown filter in Reports
    $(".f_year").find('.reportshide').hide();
    $('.f_year').find('.reportshide:first').show();
    $('.year').on('change', function() {
        var id = $(this).val();
        $(this).parents('.f_year').find(".reportshide").hide();
        $(this).parents('.f_year').find("#" + id).show();
    });
    //end

    // default open of the accordion tab 
    // $('.global_acc').find('.card:first').find('.card-header').removeClass('collapsed');
    // $('.global_acc').find('.card:first').find('.featureList').addClass('show');
    //end 


    //scrol to top as you click left side tab
    $('.inner_sbi-session .left_inner .featureMenu .nav-link').on('click', function(e) {
        $("html, body").animate({ scrollTop: 0 }, "slow");
    })

    //end

    // click accrodin to scroll to top of the accordion heading

    $.fn.slideFadeToggle = function(speed, easing, callback) {
        return this.animate({ opacity: 'toggle', height: 'toggle' }, speed, easing, callback);
    };

    //accordion
    $('.global_acc .card-header').accordion({
        defaultOpen: 'default_20',

        speed: 'slow',
        animateOpen: function(elem, opts) { //replace the standard slideUp with custom function
            elem.next().stop(true, true).slideFadeToggle(opts.speed, function() {
                console.log($(elem).offset().top)
                $('html, body').stop().animate({
                    scrollTop: $(elem).offset().top - 100
                }, 500);
            });
        },
        animateClose: function(elem, opts) { //replace the standard slideDown with custom function
            elem.next().stop(true, true).slideFadeToggle(opts.speed);
        },

    });
    //end

    //carousel
    $('.carousel').carousel({
        pause: "false"
    });
    //end

    // in footer for locator
    $(".pop").popover({ trigger: "manual", html: true, animation: true })
        .on("mouseenter", function() {
            var _this = this;
            $(this).popover("show");
            $(".popover").on("mouseleave", function() {
                $(_this).popover('hide');
            });
        }).on("mouseleave", function() {
            var _this = this;
            setTimeout(function() {
                if (!$(".popover:hover").length) {
                    $(_this).popover("hide");
                }
            }, 300);
        });
    //end
    
 // Add New popup for footer locator
    
    /*
    $(document).on("click","#close_locator",function ()
    {	
    	$("#atmlocmodal_new").css('display','none');
    	$(".modal-backdrop").hide();
    			
    });	
    */
   
    /* start Disable right click and few click */
document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    alert("Right-click functionality is disabled on this website.");
}, false);
function ctrlShiftKey(e, keyCode) {
    return e.ctrlKey && e.shiftKey && e.keyCode === keyCode.charCodeAt(0);
}

document.onkeydown = (e) => {
    // Disable F12, Ctrl + Shift + I, Ctrl + Shift + J, Ctrl + U
    if (
        event.keyCode === 123 || event.keyCode == 18 ||
        ctrlShiftKey(e, 'I') ||
        ctrlShiftKey(e, 'J') ||
        ctrlShiftKey(e, 'C') ||
        (e.ctrlKey && e.keyCode === 'U'.charCodeAt(0))
    )
        return false;
};
/* end Disable right click and few click */
    
    
    
    

});