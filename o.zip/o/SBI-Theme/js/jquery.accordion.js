! function(t) {
    function s(e) { opened = t(document).find("." + e.cssOpen), t.each(opened, function() { t(this).addClass(e.cssClose).removeClass(e.cssOpen), e.animateClose(t(this), e) }) }

    function d(e, n) { if (e.hasClass(n.cssOpen)) return s(n), void(a(n) && l("", n)); var o, i;
        s(n), o = e, s(i = n), o.removeClass(i.cssClose).addClass(i.cssOpen), i.animateOpen(o, i), a(i) && (id = o.attr("id"), l(id, i)) }

    function a(e) { return !(!t.cookie || "" == e.cookieName) }

    function l(e, n) { a(n) && t.cookie(n.cookieName, e, n.cookieOptions) }

    function u(e) { return !(!a(e) || null == t.cookie(e.cookieName)) }
    t.fn.accordion = function(e) { if (!this || this.length < 1) return this; var n, o, s, c;
        n = this, o = e, s = t.extend({}, t.fn.accordion.defaults, o), c = "", n.each(function() { var e, n, o, i = t(this);
            e = s, i.data("accordion-opts", e), "mouseenter" == s.bind && i.bind("mouseenter", function(e) { e.preventDefault(), d(i, s) }), "mouseover" == s.bind && i.bind("mouseover", function(e) { e.preventDefault(), d(i, s) }), "click" == s.bind && i.bind("click", function(e) { e.preventDefault(), d(i, s) }), "dblclick" == s.bind && i.bind("dblclick", function(e) { e.preventDefault(), d(i, s) }), id = i.attr("id"), a(s) && u(s) ? !1 == (n = id, !!a(o = s) && !!u(o) && (cookie = unescape(t.cookie(o.cookieName)), cookie == n)) ? (i.addClass(s.cssClose), s.loadClose(i, s)) : (i.addClass(s.cssOpen), s.loadOpen(i, s), c = id) : id != s.defaultOpen ? (i.addClass(s.cssClose), s.loadClose(i, s)) : (i.addClass(s.cssOpen), s.loadOpen(i, s), c = id) }), 0 < c.length && a(s) ? l(c, s) : l("", s) }, t.fn.accordion.defaults = { cssClose: "accordion-close", cssOpen: "accordion-open", cookieName: "accordion", cookieOptions: { path: "/", expires: 7, domain: "", secure: "" }, defaultOpen: "", speed: "slow", bind: "click", animateOpen: function(e, n) { e.next().stop(!0, !0).slideDown(n.speed) }, animateClose: function(e, n) { e.next().stop(!0, !0).slideUp(n.speed) }, loadOpen: function(e, n) { e.next().show() }, loadClose: function(e, n) { e.next().hide() } } }(jQuery);