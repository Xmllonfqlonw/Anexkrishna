/*1718451034000*/
AUI().ready(function(){});Liferay.Portlet.ready(function(portletId,node){});Liferay.on("allPortletsReady",function(){});